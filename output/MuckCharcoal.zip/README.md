# What It Does
This plugin adds Charcoal. Any type of Wood can be burned in a Furnace to produce Charcoal, which functions similarly to coal.

# Configurable
When running Muck for the first time with this plugin installed, MuckCharcoal.cfg will be created in the BepinEx/config folder.
The configurable aspects of this plugin are:

- The items which can be turned into charcoal by processing in a furnace
- How long it takes an item to be processed into charcoal
- How many items a single piece of charcoal can smelt/cook in a furnace/cauldron